const cardArray = [{
    name: '1',
    img: 'https://cdn-icons-png.flaticon.com/512/1998/1998627.png'
},
{
    name: '2',
    img: 'https://cdn-icons-png.flaticon.com/512/1998/1998592.png'
},
{
    name: '3',
    img: 'https://cdn-icons-png.flaticon.com/512/4300/4300519.png'
},
{
    name: '4',
    img: 'https://cdn-icons-png.flaticon.com/512/25/25694.png'
},
{
    name: '5',
    img: 'https://cdn-icons-png.flaticon.com/512/3132/3132299.png'
},
{
    name: '6',
    img: 'https://cdn-icons-png.flaticon.com/512/1136/1136897.png'
}
    , {
    name: '1',
    img: 'https://cdn-icons-png.flaticon.com/512/1998/1998627.png'
}
    , {
    name: '2',
    img: 'https://cdn-icons-png.flaticon.com/512/1998/1998592.png'
}
    , {
    name: '3',
    img: 'https://cdn-icons-png.flaticon.com/512/4300/4300519.png'
}
    , {
    name: '4',
    img: 'https://cdn-icons-png.flaticon.com/512/25/25694.png'
}
    , {
    name: '5',
    img: 'https://cdn-icons-png.flaticon.com/512/3132/3132299.png'
},
{
    name: '6',
    img: 'https://cdn-icons-png.flaticon.com/512/1136/1136897.png'
}
]

const board = document.querySelector('.board')
const placeholder = 'https://cloud-5ystxzer7.vercel.app/7placeholder.png';
const blank = 'https://cloud-5ystxzer7.vercel.app/6blank.png';

cardArray.sort(() => 0.5 - Math.random())
var cardsClicked = [];
var cardsClickedId = [];
var cardsMatched = [];
  

function createBoard() {
  for (let i = 0; i < cardArray.length; i++){
    var card = document.createElement('img')
    card.setAttribute('src', placeholder)
    card.setAttribute('data-id', i)
    card.style.width = '100px';
    card.addEventListener('click', flipCard)
    board.appendChild(card)
  }
    // code goes here
}

function flipCard() {
  const cardId = this.getAttribute("data-id");
  cardsClicked.push(cardArray[cardId].name);
  cardsClickedId.push(cardId);
  this.setAttribute('src', cardArray[cardId].img)

  if (cardsClicked.length === 2) {
    checkForMatch();

    cardsClicked = []
    cardsClickedId = []
  }
    // code goes here
}

function checkForMatch() {
  var cards = document.querySelectorAll('img');

  const firstCard = cardsClickedId[0];
  const secondCard = cardsClickedId[1];
  if (firstCard === secondCard) {
    cards[firstCard].setAttribute("src", placeholder)
    cards[secondCard].setAttribute("src", placeholder)
    alert("You have clicked the same image!")
  } else if (cardsClicked[0] === cardsClicked[1]) {
    cards[secondCard].setAttribute("src", blank)
    cards[firstCard].setAttribute("src", blank)
    cardsMatched.push(cardsClicked);
    cards[firstCard].removeEventListener('click', flipCard)
    cards[secondCard].removeEventListener('click', flipCard)
  } else {
    setTimeout(() => {
      cards[firstCard].setAttribute('src', placeholder)
      cards[secondCard].setAttribute('src', placeholder)
    }, 500)
  }
    //code goes here
}

createBoard();